"""Điều khiển WASD tích hợp ESP32 ultrasonic fail-safe + Camera Stream cho HCROBOT."""

import argparse
import logging
import os
import threading
import time

from motor_controller import MotorController, get_char, load_config, run_wasd_controller
from obstacle_safety import ObstacleSafetyController
from ultrasonic_serial import UltrasonicSerialReader


logger = logging.getLogger("RobotMain")


def start_camera_stream(device=None, width=640, height=480, fps=15):
    """Khởi động MJPEG Camera Stream Server trên background thread với Frame Broadcaster và auto-reconnect."""
    try:
        from scripts.camera_stream import (
            create_camera_backend,
            ThreadedHTTPServer,
            MJPEGHandler,
            CameraBroadcaster,
        )
        import scripts.camera_stream as cam_module

        broadcaster = CameraBroadcaster(width=width, height=height, fps=fps, device=device)
        broadcaster.start()
        cam_module.camera_broadcaster = broadcaster
        cam_module.camera_backend = broadcaster.backend

        server = ThreadedHTTPServer(("0.0.0.0", 8554), MJPEGHandler)
        logger.info("📹 Camera stream started: http://0.0.0.0:8554/stream (Broadcaster Enabled)")
        server.serve_forever()
    except Exception as e:
        logger.error(f"Camera stream failed to start: {e}")


_wsl_sync_sock = None

def _notify_wsl_motion(motion: str):
    global _wsl_sync_sock
    try:
        if _wsl_sync_sock is None:
            import socket
            _wsl_sync_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            _wsl_sync_sock.settimeout(0.02)
        # Gửi sang laptop WSL để RViz2 cập nhật chuyển động tức thời
        _wsl_sync_sock.sendto(motion.encode('utf-8'), ("100.92.82.61", 9998))
    except Exception:
        pass


def start_udp_control_listener(safety, port=9999):
    """Khởi động UDP Remote Listener trên background thread để nhận lệnh điều khiển từ xa."""
    import socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.bind(("0.0.0.0", port))
        sock.settimeout(0.2)
        logger.info("📡 UDP Remote Control Listener started on 0.0.0.0:%d", port)
    except Exception as e:
        logger.warning("Không thể khởi chạy UDP port %d: %s", port, e)
        return

    motion_map = {
        "w": "forward", "forward": "forward", "up": "forward",
        "s": "backward", "backward": "backward", "down": "backward",
        "a": "left", "left": "left",
        "d": "right", "right": "right",
        "wa": "forward_left", "aw": "forward_left", "forward_left": "forward_left", "up_left": "forward_left",
        "wd": "forward_right", "dw": "forward_right", "forward_right": "forward_right", "up_right": "forward_right",
        "sa": "backward_left", "as": "backward_left", "backward_left": "backward_left", "down_left": "backward_left",
        "sd": "backward_right", "ds": "backward_right", "backward_right": "backward_right", "down_right": "backward_right",
        "x": "stop", "stop": "stop", " ": "stop"
    }

    try:
        while True:
            try:
                data, _ = sock.recvfrom(1024)
                cmd = data.decode("utf-8", errors="ignore").strip().lower()
                if cmd.startswith("speed:") or cmd.startswith("speed_"):
                    val_str = cmd.replace("speed:", "").replace("speed_", "").strip()
                    try:
                        spd = int(val_str)
                        if hasattr(safety, "set_speed"):
                            safety.set_speed(spd)
                    except ValueError:
                        pass
                    continue

                if cmd in motion_map:
                    target_motion = motion_map[cmd]
                    if target_motion == "stop":
                        safety.stop()
                    else:
                        safety.command(target_motion)
            except socket.timeout:
                pass
            except Exception as e:
                logger.debug("UDP listener error: %s", e)
    finally:
        sock.close()


class DirectMotorSafetyWrapper:
    """Wrapper cho phép điều khiển motor trực tiếp khi chạy mode không cảm biến (--motor-only hoặc --no-safety)."""
    def __init__(self, motor):
        self.motor = motor
        self.motion = "stop"
        self.actions = {
            "forward": motor.forward,
            "backward": motor.backward,
            "left": motor.turn_left,
            "right": motor.turn_right,
            "forward_left": motor.turn_forward_left,
            "forward_right": motor.turn_forward_right,
            "backward_left": motor.turn_backward_left,
            "backward_right": motor.turn_backward_right,
        }

    def command(self, motion: str) -> bool:
        if motion == "stop":
            self.stop()
            return True
        if motion == self.motion:
            return True
        action = self.actions.get(motion)
        if action:
            action()
            self.motion = motion
            return True
        return False

    def stop(self):
        if self.motion != "stop":
            self.motor.stop()
            self.motion = "stop"

    def set_speed(self, speed_percent: int) -> int:
        if hasattr(self.motor, "set_speed"):
            return self.motor.set_speed(speed_percent)
        return 100

    @property
    def speed(self) -> int:
        return getattr(self.motor, "speed", 100)

    def update(self):
        pass

    def enforce(self) -> bool:
        return True


def _value(cli_value, config, key, default):
    return cli_value if cli_value is not None else config.get(key, default)


def run_direct_motor_test(motor, direction, duration_seconds=10.0, countdown=3):
    """Chạy motor trực tiếp, không mở Serial và không áp dụng obstacle safety."""
    actions = {
        "forward": motor.forward,
        "backward": motor.backward,
        "left": motor.turn_left,
        "right": motor.turn_right,
        "forward_left": motor.turn_forward_left,
        "forward_right": motor.turn_forward_right,
        "backward_left": motor.turn_backward_left,
        "backward_right": motor.turn_backward_right,
    }
    if direction not in actions:
        raise ValueError(f"Hướng test không hợp lệ: {direction}")

    duration_seconds = float(duration_seconds)
    if duration_seconds < 0:
        raise ValueError("Thời gian test không được âm")

    logger.warning(
        "DIRECT MOTOR TEST: bỏ qua toàn bộ ESP32/sensor. "
        "Kê bánh khỏi mặt đất và nhấn Ctrl+C để dừng khẩn cấp."
    )
    try:
        for remaining in range(int(countdown), 0, -1):
            print(f"Motor sẽ chạy {direction.upper()} sau {remaining}...")
            time.sleep(1.0)

        actions[direction]()
        if duration_seconds == 0:
            print(f"Đang chạy {direction.upper()} liên tục; nhấn Ctrl+C để DỪNG.")
            while True:
                time.sleep(0.1)
        else:
            print(
                f"Đang chạy {direction.upper()} trong {duration_seconds:.1f} giây; "
                "nhấn Ctrl+C để dừng sớm."
            )
            deadline = time.monotonic() + duration_seconds
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                time.sleep(min(0.1, remaining))
    except KeyboardInterrupt:
        logger.info("Đã nhận Ctrl+C trong direct motor test")
    finally:
        motor.cleanup()

    return 0


def run_auto_drive(safety, direction, countdown=3):
    """Tự chạy tiến/lùi và kết thúc ngay khi obstacle safety ra lệnh dừng."""
    sensor_name = {"forward": "front", "backward": "rear"}.get(direction)
    if sensor_name is None:
        raise ValueError("Auto drive chỉ hỗ trợ forward hoặc backward")

    label = direction.upper()
    sensor_label = sensor_name.upper()
    logger.warning(
        "AUTO %s: robot sẽ dừng khi %s <= ngưỡng, sensor lỗi hoặc mất Serial. "
        "Nhấn Ctrl+C để dừng thủ công.",
        label,
        sensor_name,
    )
    for remaining in range(int(countdown), 0, -1):
        print(f"Robot sẽ tự chạy {label} về phía {sensor_label} sau {remaining}...")
        time.sleep(1.0)

    safety.update()
    if not safety.command(direction):
        logger.error(
            "AUTO %s không khởi động vì điều kiện ban đầu không an toàn.", label
        )
        return 4

    logger.info("AUTO %s đang chạy; chờ vật cản phía %s...", label, sensor_label)
    while safety.motion == direction:
        if not safety.enforce():
            logger.info("AUTO %s đã dừng an toàn và sẽ không tự chạy lại.", label)
            break
        time.sleep(0.01)
    return 0


def run_auto_forward(safety, countdown=3):
    """Alias tương thích với lệnh --auto-forward cũ."""
    return run_auto_drive(safety, "forward", countdown=countdown)


def _print_controls(port, thresholds=None, stale_timeout=0.0, turn_clearance=0.0):
    print("\n" + "=" * 68)
    print(" HCROBOT: MOTOR + 4 HC-SR04 QUA ESP32 USB SERIAL")
    print("=" * 68)
    print(" [Q/7] tiến-trái    [W/8/↑] tiến      [E/9] tiến-phải")
    print(" [A/4/←] xoay-trái  [X/5/Space] dừng  [D/6/→] xoay-phải")
    print(" [Z/1] lùi-trái     [S/2/↓] lùi       [C/3] lùi-phải")
    print(" [[] Chậm (50%)     [\\] Vừa (75%)     []] Nhanh (100%)  [+/-] Tăng/giảm 10%")
    print(" [P/Ctrl+C] thoát")
    if thresholds:
        print(f" Serial: {port} | stale timeout: {stale_timeout:.2f}s")
        print(
            " Ngưỡng: front={forward:.1f} rear={backward:.1f} "
            "left={left:.1f} right={right:.1f} cm".format(**thresholds)
        )
        print(f" Khi quay: kiểm tra bên quay + front/rear > {turn_clearance:.1f}cm")
        print(" Mất Serial hoặc sensor lỗi liên tiếp => STOP; hết vật cản phải bấm lệnh lại")
    else:
        print(f" Chế độ: {port}")
    print("=" * 68 + "\n")


def build_argument_parser():
    parser = argparse.ArgumentParser(
        description="Điều khiển motor L298N với ultrasonic fail-safe từ ESP32"
    )
    parser.add_argument("--port", help="Cổng ESP32, ví dụ /dev/ttyUSB0; mặc định auto")
    parser.add_argument("--baud", type=int, help="Baud rate ESP32")
    parser.add_argument("--front-stop", type=float, help="Ngưỡng dừng phía trước (cm)")
    parser.add_argument("--rear-stop", type=float, help="Ngưỡng dừng phía sau (cm)")
    parser.add_argument("--left-stop", type=float, help="Ngưỡng chặn xoay trái (cm)")
    parser.add_argument("--right-stop", type=float, help="Ngưỡng chặn xoay phải (cm)")
    parser.add_argument("--sensor-timeout", type=float, help="Tuổi packet tối đa (giây)")
    parser.add_argument(
        "--null-grace",
        type=float,
        help="Thời gian giữ 1 số đo trước khi null (giây)",
    )
    parser.add_argument(
        "--turn-clearance",
        type=float,
        help="Khoảng trống front/rear khi quay (cm)",
    )
    parser.add_argument(
        "--resume-margin",
        type=float,
        help="Biên mở khóa cao hơn ngưỡng dừng (cm)",
    )
    parser.add_argument(
        "--resume-packets",
        type=int,
        help="Số packet sạch liên tiếp để mở khóa",
    )
    parser.add_argument("--gpio-chip", type=int, help="Ép gpiochip; thường tự phát hiện")
    parser.add_argument("--mock", action="store_true", help="Giả lập motor nhưng vẫn đọc sensor")
    parser.add_argument("--no-camera", action="store_true", help="Không khởi động camera stream")
    parser.add_argument("--no-lidar", action="store_true", help="Không khởi động LiDAR SLAM stream")
    parser.add_argument(
        "--lidar-port",
        default=None,
        help="Cổng Serial cho RPLiDAR (mặc định tự dò hoặc /dev/ttyUSB1)",
    )
    parser.add_argument(
        "--camera-device",
        default=None,
        help="Device index hoặc path cho USB camera (ví dụ: 0, 16 hoặc /dev/video16)",
    )
    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument(
        "--drive-test",
        choices=("forward", "backward", "left", "right"),
        help="Chạy motor trực tiếp theo hướng chọn, bỏ qua toàn bộ sensor",
    )
    parser.add_argument(
        "--drive-test-seconds",
        type=float,
        default=10.0,
        help="Thời gian direct motor test; đặt 0 để chạy tới khi nhấn Ctrl+C",
    )
    mode_group.add_argument(
        "--auto-forward",
        action="store_true",
        help="Alias cũ của --auto-drive forward",
    )
    mode_group.add_argument(
        "--auto-drive",
        choices=("forward", "backward"),
        help="Tự chạy tiến/lùi và dừng hẳn bằng sensor FRONT/REAR tương ứng",
    )
    mode_group.add_argument(
        "--motor-only",
        action="store_true",
        help="Test motor không dùng sensor (không có obstacle fail-safe)",
    )
    parser.add_argument(
        "--no-safety",
        action="store_true",
        help="Bỏ qua khóa fail-safe cảm biến siêu âm (cho phép điều khiển trực tiếp qua Web/phím)",
    )
    parser.add_argument(
        "--ignore-sensors",
        default="",
        help="Danh sách cảm biến siêu âm bỏ qua kiểm tra an toàn (ví dụ: front hoặc front,rear)",
    )
    parser.add_argument("--debug", action="store_true", help="Bật log từng packet")
    return parser


def main(argv=None):
    # 0. Ngăn ngừa chạy trùng lặp tiến trình gây tranh chấp cổng Serial /dev/ttyUSB0
    try:
        import fcntl
        global _instance_lock_file
        lock_path = os.path.expanduser("~/.hcrobot_main.lock")
        _instance_lock_file = open(lock_path, "w")
        fcntl.flock(_instance_lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        _instance_lock_file.write(str(os.getpid()))
        _instance_lock_file.flush()
    except (IOError, BlockingIOError) as e:
        if isinstance(e, BlockingIOError) or "Resource temporarily unavailable" in str(e):
            print("\n" + "=" * 65)
            print("🚨 [LỖI] ĐÃ CÓ TIẾN TRÌNH HC-ROBOT ĐANG CHẠY TRÊN HỆ THỐNG!")
            print("Cổng Serial và GPIO sẽ bị xung đột nếu chạy 2 instance cùng lúc.")
            print("Vui lòng dừng tiến trình cũ trước bằng lệnh: sudo killall -9 python3")
            print("=" * 65 + "\n")
            return 1
    except Exception:
        pass

    args = build_argument_parser().parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.debug else logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    config = load_config()
    robot_cfg = config.get("robot", {})
    gpio_cfg = robot_cfg.get("gpio", {})
    serial_cfg = robot_cfg.get("ultrasonic_serial", {})
    safety_cfg = robot_cfg.get("safety", {})

    motor = MotorController(
        left_forward_pin=gpio_cfg.get("left_forward", 17),
        left_backward_pin=gpio_cfg.get("left_backward", 27),
        right_forward_pin=gpio_cfg.get("right_forward", 22),
        right_backward_pin=gpio_cfg.get("right_backward", 23),
        force_mock=args.mock,
        gpio_chip=_value(args.gpio_chip, gpio_cfg, "chip", None),
        invert_left_direction=gpio_cfg.get("invert_left_direction", False),
        invert_right_direction=gpio_cfg.get("invert_right_direction", False),
    )

    if motor.is_mock and not args.mock:
        logger.error(
            "Không có GPIO thật; hủy chạy motor. Dùng --mock chỉ khi muốn giả lập."
        )
        motor.cleanup()
        return 2

    # Bật Camera Stream Server trên background thread (trừ khi --no-camera)
    if not args.no_camera:
        camera_thread = threading.Thread(
            target=start_camera_stream,
            args=(args.camera_device,),
            daemon=True,
        )
        camera_thread.start()

    # Bật LiDAR SLAM & WebSocket Server trên background thread (trừ khi --no-lidar)
    if not args.no_lidar:
        try:
            from scripts.lidar_service import run_lidar_server, slam_core
            slam_core.pi_motor = motor  # Dùng chung instance MotorController đã claim GPIO thành công
            if args.lidar_port:
                slam_core.port = args.lidar_port
            lidar_thread = threading.Thread(
                target=run_lidar_server,
                kwargs={"host": "0.0.0.0", "port": 8000},
                daemon=True,
            )
            lidar_thread.start()
            logger.info("📡 LiDAR SLAM Server đang chạy tại ws://0.0.0.0:8000/api/v1/map/ws")
        except Exception as e:
            logger.warning("Không thể khởi chạy LiDAR SLAM Server: %s", e)

    if args.drive_test:
        return run_direct_motor_test(
            motor,
            args.drive_test,
            duration_seconds=args.drive_test_seconds,
        )

    if args.motor_only:
        logger.warning(
            "MOTOR-ONLY: ultrasonic fail-safe đã bị tắt. Hãy kê bánh khỏi mặt đất khi test."
        )
        safety = DirectMotorSafetyWrapper(motor)
        udp_thread = threading.Thread(
            target=start_udp_control_listener,
            args=(safety, 9999),
            daemon=True,
        )
        udp_thread.start()
        run_wasd_controller(motor)
        return 0

    active_lidar_port = None
    if not args.no_lidar:
        try:
            from scripts.lidar_service import slam_core
            active_lidar_port = slam_core.port
        except Exception:
            pass

    port = _value(args.port, serial_cfg, "port", "auto")
    exclude = [active_lidar_port] if active_lidar_port else []
    baudrate = int(_value(args.baud, serial_cfg, "baudrate", 115200))

    from ultrasonic_serial import detect_esp32_port
    esp32_port = detect_esp32_port(exclude_ports=exclude) if port == "auto" else port

    reader = None
    if esp32_port:
        try:
            reader = UltrasonicSerialReader(port=esp32_port, baudrate=baudrate, exclude_ports=exclude)
            reader.start()
            if not args.no_lidar:
                try:
                    from scripts.lidar_service import slam_core
                    slam_core.esp32_reader = reader
                except Exception:
                    pass
            logger.info("📡 Đã khởi động luồng đọc cảm biến siêu âm & Encoder từ ESP32 trên %s", esp32_port)
        except Exception as e:
            logger.warning("⚠️ Không mở được Serial ESP32 (%s).", e)
            reader = None

    if args.no_safety:
        logger.warning(
            "⚠️ NO-SAFETY: Đã tắt khóa an toàn cảm biến siêu âm. Điều khiển Web và bàn phím sẽ tác động trực tiếp tới motor."
        )
        safety = DirectMotorSafetyWrapper(motor)
        # Bật UDP Remote Control Listener trên background thread (port 9999)
        udp_thread = threading.Thread(
            target=start_udp_control_listener,
            args=(safety, 9999),
            daemon=True,
        )
        udp_thread.start()
        _print_controls("disabled (--no-safety)", {}, 0.0, 0.0)
    else:
        if not reader:
            logger.warning(
                f"⚠️ Không tìm thấy cổng USB riêng cho ESP32 (cổng {active_lidar_port} đang dùng cho RPLiDAR). "
                "Tự động chuyển sang chế độ --no-safety để điều khiển xe bình thường."
            )
            safety = DirectMotorSafetyWrapper(motor)
            udp_thread = threading.Thread(
                target=start_udp_control_listener,
                args=(safety, 9999),
                daemon=True,
            )
            udp_thread.start()
            _print_controls("disabled (auto fallback: no ESP32 found)", {}, 0.0, 0.0)
            run_wasd_controller(motor)
            return 0

        stale_timeout = float(
            _value(args.sensor_timeout, safety_cfg, "stale_timeout_seconds", 0.4)
        )
        thresholds = {
            "forward": float(_value(args.front_stop, safety_cfg, "front_stop_cm", 65.0)),
            "backward": float(_value(args.rear_stop, safety_cfg, "rear_stop_cm", 65.0)),
            "left": float(_value(args.left_stop, safety_cfg, "left_stop_cm", 25.0)),
            "right": float(_value(args.right_stop, safety_cfg, "right_stop_cm", 25.0)),
        }
        invalid_grace = float(
            _value(args.null_grace, safety_cfg, "invalid_grace_seconds", 0.2)
        )
        allowed_null_packets = int(safety_cfg.get("allowed_null_packets", 1))
        resume_margin = float(
            _value(args.resume_margin, safety_cfg, "resume_margin_cm", 10.0)
        )
        resume_packets = int(
            _value(args.resume_packets, safety_cfg, "resume_valid_packets", 3)
        )
        turn_clearance = float(
            _value(args.turn_clearance, safety_cfg, "turn_clearance_cm", 25.0)
        )

        ignored = [s.strip().lower() for s in args.ignore_sensors.split(",") if s.strip()]
        if ignored:
            logger.info("🛡️ Cấu hình bỏ qua cảm biến an toàn: %s", ", ".join(ignored).upper())

        safety = ObstacleSafetyController(
            motor=motor,
            sensor_reader=reader,
            thresholds_cm=thresholds,
            stale_timeout=stale_timeout,
            invalid_grace=invalid_grace,
            allowed_null_packets=allowed_null_packets,
            resume_margin_cm=resume_margin,
            resume_valid_packets=resume_packets,
            turn_clearance_cm=turn_clearance,
            ignored_sensors=ignored,
        )

        if reader.wait_for_packet(timeout=4.5):
            logger.info("Đã nhận packet ultrasonic đầu tiên; khóa fail-safe sẵn sàng.")
        else:
            logger.warning(
                "⚠️ Không nhận được packet từ ESP32 sau 4.5 giây (cổng %s).",
                port,
            )
            logger.warning(
                "🔄 TỰ ĐỘNG CHUYỂN SANG NO-SAFETY: Bỏ qua khóa siêu âm để cho phép điều khiển xe ngay (LiDAR 360° vẫn bảo vệ)."
            )
            safety = DirectMotorSafetyWrapper(motor)

        _print_controls(port, thresholds, stale_timeout, turn_clearance)

        # Bật UDP Remote Control Listener trên background thread (port 9999)
        udp_thread = threading.Thread(
            target=start_udp_control_listener,
            args=(safety, 9999),
            daemon=True,
        )
        udp_thread.start()

    key_to_motion = {
        # 4 hướng cơ bản:
        "w": "forward",
        "s": "backward",
        "a": "left",
        "d": "right",
        # 4 hướng chéo (bẻ lái vòng cung QWERTY):
        "q": "forward_left",
        "e": "forward_right",
        "z": "backward_left",
        "c": "backward_right",
        # Bàn phím số Numpad:
        "7": "forward_left",
        "8": "forward",
        "9": "forward_right",
        "4": "left",
        "6": "right",
        "1": "backward_left",
        "2": "backward",
        "3": "backward_right",
    }
    last_status_at = 0.0
    last_status_sequence = 0

    try:
        auto_direction = args.auto_drive or ("forward" if args.auto_forward else None)
        if auto_direction:
            return run_auto_drive(safety, auto_direction)

        while True:
            safety.enforce()

            snapshot = reader.latest() if reader else None
            now = time.monotonic()
            if now - last_status_at >= 1.0:
                last_status_at = now
                if snapshot:
                    last_status_sequence = snapshot.sequence
                    logger.info(
                        "SONAR cm: front=%s rear=%s left=%s right=%s age=%.2fs",
                        snapshot.distance("front"),
                        snapshot.distance("rear"),
                        snapshot.distance("left"),
                        snapshot.distance("right"),
                        snapshot.age_seconds(now),
                    )
                    if snapshot.mpu_available:
                        logger.info(
                            "IMU: accel_g=%s gyro_dps=%s yaw_rate=%s dps",
                            snapshot.accel,
                            snapshot.gyro,
                            snapshot.yaw_rate_dps,
                        )
                    if getattr(snapshot, "encoders", None):
                        encs = snapshot.encoders
                        logger.info(
                            "ENCODER: M1=%s M2=%s | M3=%s M4=%s (ticks)",
                            encs.get("m1", {}).get("ticks", 0),
                            encs.get("m2", {}).get("ticks", 0),
                            encs.get("m3", {}).get("ticks", 0),
                            encs.get("m4", {}).get("ticks", 0),
                        )

                # Hiển thị khoảng cách vật cản 360° đo bởi RPLiDAR
                try:
                    from scripts.lidar_service import slam_core
                    if getattr(slam_core, "is_running", False) or getattr(slam_core, "is_connected", False):
                        lf = f"{slam_core.get_front_distance() * 100:.1f}" if slam_core.get_front_distance() < 90 else "clear"
                        lr = f"{slam_core.get_rear_distance() * 100:.1f}" if slam_core.get_rear_distance() < 90 else "clear"
                        ll = f"{slam_core.get_left_distance() * 100:.1f}" if slam_core.get_left_distance() < 90 else "clear"
                        lrg = f"{slam_core.get_right_distance() * 100:.1f}" if slam_core.get_right_distance() < 90 else "clear"
                        logger.info(
                            "LIDAR cm: front=%s rear=%s left=%s right=%s (360°)",
                            lf, lr, ll, lrg,
                        )
                except Exception:
                    pass

            char = get_char()
            if not char:
                time.sleep(0.01)
                continue
            key = char.lower()
            if key in key_to_motion:
                target_cmd = key_to_motion[key]
                safety.command(target_cmd)
                _notify_wsl_motion(target_cmd)
            elif key in ("x", "5", " ", "\r", "\n"):
                safety.stop()
                _notify_wsl_motion("stop")
            elif key in ("+", "="):
                new_spd = safety.set_speed(safety.speed + 10)
                logger.info("Vận tốc: %d%%", new_spd)
            elif key in ("-", "_"):
                new_spd = safety.set_speed(safety.speed - 10)
                logger.info("Vận tốc: %d%%", new_spd)
            elif key == "[":
                new_spd = safety.set_speed(50)
                logger.info("Vận tốc Cấp 1 (Chậm): %d%%", new_spd)
            elif key == "\\":
                new_spd = safety.set_speed(75)
                logger.info("Vận tốc Cấp 2 (Vừa): %d%%", new_spd)
            elif key == "]":
                new_spd = safety.set_speed(100)
                logger.info("Vận tốc Cấp 3 (Nhanh): %d%%", new_spd)
            elif key == "p" or char == "\x03":
                logger.info("Nhận lệnh thoát")
                break
    except KeyboardInterrupt:
        logger.info("Đã ngắt bằng Ctrl+C")
    finally:
        safety.stop()
        if reader:
            reader.stop()
        motor.cleanup()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
