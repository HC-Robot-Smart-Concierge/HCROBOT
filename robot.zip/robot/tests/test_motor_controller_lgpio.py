import os
import sys
import unittest
from unittest.mock import patch


sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import motor_controller


class FakeLGPIO:
    def __init__(self, failing_chips=None):
        self.failing_chips = set(failing_chips or [])
        self.opened = []
        self.claimed = []
        self.freed = []
        self.closed = []
        self.writes = []
        self.pwm_calls = []

    def gpiochip_open(self, chip_num):
        self.opened.append(chip_num)
        if chip_num in self.failing_chips:
            raise RuntimeError("can not open gpiochip")
        return 100 + chip_num

    def gpio_claim_output(self, handle, pin, value):
        self.claimed.append((handle, pin, value))

    def gpio_write(self, handle, pin, value):
        self.writes.append((handle, pin, value))

    def tx_pwm(self, handle, pin, frequency, duty_cycle):
        self.pwm_calls.append((handle, pin, frequency, duty_cycle))

    def gpio_free(self, handle, pin):
        self.freed.append((handle, pin))

    def gpiochip_close(self, handle):
        self.closed.append(handle)


class TestLGPIOBackend(unittest.TestCase):
    def test_uses_configured_chip_and_one_shared_handle(self):
        fake_lgpio = FakeLGPIO()
        with (
            patch.object(motor_controller, "lgpio", fake_lgpio, create=True),
            patch.object(motor_controller, "HAS_LGPIO", True),
            patch.object(motor_controller, "HAS_GPIOZERO", False),
        ):
            controller = motor_controller.MotorController(
                left_forward_pin=17,
                left_backward_pin=27,
                right_forward_pin=22,
                right_backward_pin=23,
                gpio_chip=7,
            )

            self.assertFalse(controller.is_mock)
            self.assertEqual(controller.gpio_chip_num, 7)
            self.assertEqual(fake_lgpio.opened, [7])
            self.assertEqual(fake_lgpio.claimed, [
                (107, 17, 0),
                (107, 27, 0),
                (107, 22, 0),
                (107, 23, 0),
            ])

            controller.forward()
            self.assertEqual(fake_lgpio.pwm_calls, [])
            self.assertEqual(fake_lgpio.writes[-2:], [(107, 17, 1), (107, 22, 1)])

            controller.cleanup()
            self.assertEqual(fake_lgpio.closed, [107])
            self.assertEqual(
                sorted(pin for _, pin in fake_lgpio.freed),
                [17, 22, 23, 27],
            )

    def test_speed_control_activates_pwm(self):
        fake_lgpio = FakeLGPIO()
        with (
            patch.object(motor_controller, "lgpio", fake_lgpio, create=True),
            patch.object(motor_controller, "HAS_LGPIO", True),
            patch.object(motor_controller, "HAS_GPIOZERO", False),
        ):
            controller = motor_controller.MotorController(
                left_forward_pin=17,
                left_backward_pin=27,
                right_forward_pin=22,
                right_backward_pin=23,
                gpio_chip=0,
                default_speed=50,
            )
            self.assertEqual(controller.speed, 50)
            controller.forward()
            # Ở 50% PWM, hàm tx_pwm phải được gọi với duty=50
            self.assertIn((100, 17, 100, 50), fake_lgpio.pwm_calls)
            self.assertIn((100, 22, 100, 50), fake_lgpio.pwm_calls)

            # Đổi sang 75%
            controller.set_speed(75)
            self.assertEqual(controller.speed, 75)
            self.assertIn((100, 17, 100, 75), fake_lgpio.pwm_calls)
            self.assertIn((100, 22, 100, 75), fake_lgpio.pwm_calls)

            controller.stop()
            controller.cleanup()


if __name__ == "__main__":
    unittest.main()

