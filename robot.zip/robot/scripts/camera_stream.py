#!/usr/bin/env python3
"""
MJPEG Camera Stream Server — Raspberry Pi 5.

Chạy HTTP server phát video stream MJPEG từ camera Pi 5.
Hỗ trợ Picamera2 (Camera Module CSI) + OpenCV fallback (USB webcam).

Usage trên Pi 5:
    python3 camera_stream.py
    python3 camera_stream.py --port 8554 --fps 15 --width 1280 --height 720

SSH Tunnel từ Windows:
    ssh -L 8554:localhost:8554 pi@<PI5_IP> -N

Sau đó mở: http://localhost:8554/stream
"""
import io
import sys
import time
import signal
import logging
import argparse
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler

logger = logging.getLogger("pi5-camera")

DEFAULT_PORT = 8554
DEFAULT_FPS = 15
DEFAULT_WIDTH = 640
DEFAULT_HEIGHT = 480


def suppress_c_stderr():
    """Chuyển hướng C-level stderr (fd 2) sang /dev/null để ẩn các thông báo Corrupt JPEG data từ libjpeg."""
    import os
    import sys
    if sys.platform != "win32":
        try:
            devnull = os.open(os.devnull, os.O_WRONLY)
            os.dup2(devnull, 2)
            os.close(devnull)
        except Exception:
            pass


class CameraBackend:
    """Abstract camera backend interface."""

    def __init__(self, width, height, fps):
        self.width = width
        self.height = height
        self.fps = fps

    def start(self):
        raise NotImplementedError

    def capture_jpeg(self):
        raise NotImplementedError

    def stop(self):
        raise NotImplementedError


class Picamera2Backend(CameraBackend):
    """Backend sử dụng Picamera2 cho Camera Module CSI trên Pi 5."""

    def __init__(self, width, height, fps):
        super().__init__(width, height, fps)
        self._camera = None

    def start(self):
        from picamera2 import Picamera2

        self._camera = Picamera2()
        config = self._camera.create_video_configuration(
            main={"size": (self.width, self.height), "format": "RGB888"}
        )
        self._camera.configure(config)
        self._camera.start()
        logger.info(
            f"Picamera2 started: {self.width}x{self.height} @ {self.fps}fps"
        )

    def capture_jpeg(self):
        buf = io.BytesIO()
        self._camera.capture_file(buf, format="jpeg")
        return buf.getvalue()

    def stop(self):
        if self._camera:
            self._camera.stop()
            self._camera.close()
            self._camera = None


def get_v4l2_video_devices():
    """Lấy danh sách các video device index thực sự là camera trên hệ thống Linux (ưu tiên /dev/v4l/by-id)."""
    import glob
    import os
    import re

    indices = []
    # 1. Ưu tiên quét qua /dev/v4l/by-id/ (đặc trưng cho USB webcam thật)
    by_id_paths = glob.glob("/dev/v4l/by-id/*index0*") or glob.glob("/dev/v4l/by-id/*")
    for bp in by_id_paths:
        try:
            target = os.path.realpath(bp)
            m = re.search(r"/dev/video(\d+)$", target)
            if m:
                idx = int(m.group(1))
                if idx not in indices:
                    indices.append(idx)
        except Exception:
            pass

    # 2. Quét tiếp các node /dev/video* còn lại
    dev_paths = glob.glob("/dev/video*")
    skip_keywords = ["pispbe", "rpi-hevc", "codec", "unicam-image", "metadata"]

    for p in dev_paths:
        m = re.search(r"/dev/video(\d+)$", p)
        if m:
            idx = int(m.group(1))
            if idx in indices:
                continue
            name_file = f"/sys/class/video4linux/video{idx}/name"
            if os.path.exists(name_file):
                try:
                    with open(name_file, "r") as f:
                        dev_name = f.read().strip().lower()
                    if any(kw in dev_name for kw in skip_keywords):
                        continue
                except Exception:
                    pass
            indices.append(idx)

    return indices


def normalize_video_device(device):
    """Convert numeric values and /dev/videoN paths to a V4L2 index."""
    import re

    if not isinstance(device, str):
        return device

    value = device.strip()
    if value.isdigit():
        return int(value)

    match = re.fullmatch(r"/dev/video(\d+)", value)
    if match:
        return int(match.group(1))

    return value


class OpenCVBackend(CameraBackend):
    """
    Fallback backend sử dụng OpenCV (USB webcam hoặc V4L2).
    Thiết kế với:
    - Worker thread riêng chuyên gọi cap.read() không gây lock HTTP stream.
    - Hardware Watchdog: Tự động phát hiện đơ phần cứng / sụt áp (stall > 1.5s) và tái kết nối trong nền.
    - Non-blocking capture_jpeg(): Trả về frame gần nhất hoặc placeholder trong O(1).
    """

    def __init__(self, width=640, height=480, fps=15, device=None):
        super().__init__(width, height, fps)
        self.device = device
        self._cap = None
        self._cv2 = None
        self._fail_count = 0
        self._last_reconnect_time = 0.0
        self._last_good_jpeg = None
        self._last_frame_ts = 0.0
        self._lock = threading.Lock()
        self._worker_running = False
        self._worker_thread = None
        self._reconnecting = False

    def start(self):
        with self._lock:
            import cv2

            try:
                cv2.setLogLevel(cv2.LOG_LEVEL_ERROR)
                suppress_c_stderr()
            except Exception:
                pass

            self._cv2 = cv2
            if self.device is not None:
                candidates = [normalize_video_device(self.device)]
            else:
                system_devs = get_v4l2_video_devices()
                candidates = system_devs if system_devs else [1, 0, 2, 4, 10, 14, 16, 18, 20]

            opened = False
            for dev in candidates:
                logger.info(f"Đang thử kết nối USB camera index/device {dev}...")
                cap = None
                try:
                    cap = cv2.VideoCapture(dev, cv2.CAP_V4L2)
                    if not cap.isOpened():
                        cap.release()
                        cap = cv2.VideoCapture(dev)
                except Exception:
                    cap = cv2.VideoCapture(dev)

                if cap and cap.isOpened():
                    try:
                        fourcc = cv2.VideoWriter_fourcc(*"MJPG")
                        cap.set(cv2.CAP_PROP_FOURCC, fourcc)
                    except Exception:
                        pass

                    cap.set(cv2.CAP_PROP_FPS, self.fps)
                    try:
                        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                    except Exception:
                        pass

                    # Thử độ phân giải mong muốn, nếu camera USB không nhận thì fallback xuống 480p hoặc 720p
                    res_candidates = [(self.width, self.height)]
                    if (self.width, self.height) != (640, 480):
                        res_candidates.append((640, 480))
                    if (self.width, self.height) != (1280, 720):
                        res_candidates.append((1280, 720))

                    for try_w, try_h in res_candidates:
                        cap.set(cv2.CAP_PROP_FRAME_WIDTH, try_w)
                        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, try_h)
                        ret, frame = cap.read()
                        if ret and frame is not None:
                            self._cap = cap
                            opened = True
                            actual_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                            actual_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                            self._fail_count = 0
                            try:
                                _, jpeg = self._cv2.imencode(
                                    ".jpg", frame, [self._cv2.IMWRITE_JPEG_QUALITY, 75]
                                )
                                self._last_good_jpeg = jpeg.tobytes()
                                self._last_frame_ts = time.time()
                            except Exception:
                                pass
                            logger.info(
                                f"✅ USB Camera kết nối thành công tại device {dev}: "
                                f"{actual_w}x{actual_h} @ {self.fps}fps"
                            )
                            break

                    if opened:
                        break
                    else:
                        cap.release()

            if not opened:
                raise RuntimeError(
                    f"Không thể mở USB camera qua OpenCV (đã thử index {candidates})"
                )

            # Khởi chạy frame grabber thread độc lập
            self._worker_running = True
            self._worker_thread = threading.Thread(target=self._frame_grabber_loop, daemon=True)
            self._worker_thread.start()

    def _frame_grabber_loop(self):
        """Worker thread liên tục đọc frame từ hardware mà không lock luồng HTTP."""
        logger.debug("Bắt đầu background frame grabber cho OpenCV backend.")
        while self._worker_running:
            cap = self._cap
            if cap is None or not cap.isOpened():
                time.sleep(0.05)
                continue

            try:
                ret, frame = cap.read()
            except Exception as e:
                logger.debug(f"Exception cap.read: {e}")
                ret = False
                frame = None

            if ret and frame is not None:
                try:
                    _, jpeg = self._cv2.imencode(
                        ".jpg", frame, [self._cv2.IMWRITE_JPEG_QUALITY, 75]
                    )
                    with self._lock:
                        self._last_good_jpeg = jpeg.tobytes()
                        self._last_frame_ts = time.time()
                        self._fail_count = 0
                except Exception:
                    pass
            else:
                with self._lock:
                    self._fail_count += 1
                time.sleep(0.04)

            time.sleep(0.01)

    def _trigger_async_reconnect(self):
        """Kích hoạt tiến trình kết nối lại trong nền để không bao giờ làm block HTTP stream."""
        with self._lock:
            if self._reconnecting:
                return
            now = time.time()
            if now - self._last_reconnect_time < 2.0:
                return
            self._reconnecting = True
            self._last_reconnect_time = now

        def _reconnect_task():
            logger.warning("🔄 [Camera Watchdog] Camera USB mất tín hiệu/stall. Đang quét lại cổng và tự động kết nối...")
            self.stop()
            time.sleep(0.3)
            try:
                self.start()
                logger.info("✅ [Camera Watchdog] Camera USB đã được khôi phục thành công!")
            except Exception as e:
                logger.debug(f"Khôi phục camera chưa thành công: {e}")
            finally:
                with self._lock:
                    self._reconnecting = False

        threading.Thread(target=_reconnect_task, daemon=True).start()

    def capture_jpeg(self):
        """Non-blocking: Lấy frame mới nhất. Nếu đơ quá 1.5s, tự động kích hoạt watchdog reconnect."""
        now = time.time()
        with self._lock:
            last_ts = self._last_frame_ts
            last_frame = self._last_good_jpeg
            fail_cnt = self._fail_count

        # Kiểm tra Watchdog: Quá 1.5s không nhận được frame mới từ USB hoặc fail liên tiếp 15 lần
        if (now - last_ts > 1.5 and last_ts > 0.0) or fail_cnt >= 15:
            self._trigger_async_reconnect()
            if last_frame:
                return last_frame
            return generate_placeholder_jpeg("RECOVERING CAMERA SENSOR...")

        if last_frame:
            return last_frame

        raise RuntimeError("Camera frame not available yet")

    def stop(self):
        self._worker_running = False
        with self._lock:
            if self._cap:
                try:
                    self._cap.release()
                except Exception:
                    pass
                self._cap = None


def create_camera_backend(width, height, fps, device=None):
    """Tự động chọn backend phù hợp: Thử OpenCV (USB Camera) trước -> Picamera2 (CSI Camera)."""
    # 1. Thử OpenCV trước (chuẩn cho USB webcam, hỗ trợ hardware MJPG & auto-reconnect)
    try:
        backend = OpenCVBackend(width, height, fps, device=device)
        backend.start()
        logger.info("✅ Đang sử dụng OpenCV V4L2 backend cho USB Camera.")
        return backend
    except (ImportError, RuntimeError) as e:
        logger.info(f"OpenCV USB backend không khả dụng ({e}), chuyển sang kiểm tra Picamera2 (CSI)...")

    # 2. Thử Picamera2 cho Camera Module CSI
    try:
        backend = Picamera2Backend(width, height, fps)
        backend.start()
        logger.info("✅ Đang sử dụng Picamera2 backend cho CSI Camera Module.")
        return backend
    except (ImportError, RuntimeError) as e:
        logger.error(f"Picamera2 cũng không khả dụng: {e}")
        raise RuntimeError(
            "Không tìm thấy camera backend nào (cần opencv-python hoặc picamera2)"
        )


camera_backend = None
camera_broadcaster = None


def generate_placeholder_jpeg(text="CAMERA DISCONNECTED / RECONNECTING..."):
    """Tạo một JPEG frame thông báo trạng thái khi camera đang kết nối lại để không bị màn hình đen."""
    try:
        import numpy as np
        import cv2

        img = np.zeros((480, 640, 3), dtype=np.uint8)
        # Ve border & title
        cv2.rectangle(img, (10, 10), (630, 470), (40, 40, 40), 2)
        cv2.putText(img, "HC-ROBOT VIDEO FEED", (160, 200), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 200, 255), 2)
        cv2.putText(img, text, (100, 260), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        cv2.putText(img, timestamp, (230, 310), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (180, 180, 180), 1)
        _, jpeg = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 70])
        return jpeg.tobytes()
    except Exception:
        # Fallback minimal 1x1 black JPEG byte array
        return b"\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00H\x00H\x00\x00\xff\xdb\x00C\x00\x08\x06\x06\x07\x06\x05\x08\x07\x07\x07\t\t\x08\n\x0c\x14\r\x0c\x0b\x0b\x0c\x19\x12\x13\x0f\x14\x1d\x1a\x1f\x1e\x1d\x1a\x1c\x1c $.' \",#\x1c\x1c(7),01444\x1f'9=82<.342\xff\xc0\x00\x0b\x08\x00\x01\x00\x01\x01\x01\x11\x00\xff\xc4\x00\x1f\x00\x00\x01\x05\x01\x01\x01\x01\x01\x01\x00\x00\x00\x00\x00\x00\x00\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\xff\xda\x00\x08\x01\x01\x00\x00?\x00\xbf\x00\xff\xd9"


class CameraBroadcaster:
    """Thread nền đọc camera duy nhất và broadcast khung hình mới nhất cho mọi HTTP client."""

    def __init__(self, width=640, height=480, fps=15, device=None):
        self.width = width
        self.height = height
        self.fps = fps
        self.device = device
        self.backend = None
        self._current_frame = None
        self._lock = threading.Lock()
        self._cond = threading.Condition(self._lock)
        self._running = False
        self._thread = None

    def start(self):
        try:
            self.backend = create_camera_backend(
                self.width, self.height, self.fps, device=self.device
            )
        except Exception as e:
            logger.warning(
                "Camera backend chưa sẵn sàng lúc khởi động (%s), sẽ tự động kết nối lại...", e
            )
            self.backend = None

        self._running = True
        self._thread = threading.Thread(target=self._capture_loop, daemon=True)
        self._thread.start()

    def _capture_loop(self):
        logger.info("🚀 Background Frame Broadcaster đã khởi chạy.")
        target_interval = 1.0 / self.fps
        last_reconnect_try = 0.0

        while self._running:
            now = time.time()
            if self.backend is None and (now - last_reconnect_try >= 2.0):
                last_reconnect_try = now
                try:
                    self.backend = create_camera_backend(
                        self.width, self.height, self.fps, device=self.device
                    )
                except Exception:
                    self.backend = None

            frame = None
            if self.backend:
                try:
                    frame = self.backend.capture_jpeg()
                except Exception as e:
                    logger.debug("Lỗi capture frame: %s", e)
                    frame = None

            if frame is None:
                frame = generate_placeholder_jpeg("RECONNECTING CAMERA SENSOR...")

            with self._cond:
                self._current_frame = frame
                self._cond.notify_all()

            time.sleep(target_interval)

    def get_frame(self, timeout=0.2):
        with self._cond:
            if self._current_frame is None:
                self._cond.wait(timeout=timeout)
            return self._current_frame or generate_placeholder_jpeg("INITIALIZING CAMERA...")

    def stop(self):
        self._running = False
        if self.backend:
            try:
                self.backend.stop()
            except Exception:
                pass
            self.backend = None


class MJPEGHandler(BaseHTTPRequestHandler):
    """HTTP handler phát MJPEG stream và health check."""

    def do_GET(self):
        clean_path = self.path.split("?")[0]
        if clean_path == "/stream":
            self._handle_stream()
        elif clean_path == "/health":
            self._handle_health()
        elif clean_path == "/":
            self._handle_index()
        else:
            self.send_response(404)
            self.end_headers()

    def _handle_stream(self):
        global camera_broadcaster, camera_backend
        self.send_response(200)
        self.send_header(
            "Content-Type", "multipart/x-mixed-replace; boundary=frame"
        )
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

        target_interval = 1.0 / (camera_broadcaster.fps if camera_broadcaster else 15)

        try:
            while True:
                if camera_broadcaster:
                    frame = camera_broadcaster.get_frame(timeout=0.2)
                elif camera_backend:
                    try:
                        frame = camera_backend.capture_jpeg()
                    except Exception:
                        frame = generate_placeholder_jpeg("RECONNECTING...")
                else:
                    frame = generate_placeholder_jpeg("CAMERA NOT READY...")

                self.wfile.write(b"--frame\r\n")
                self.wfile.write(b"Content-Type: image/jpeg\r\n")
                self.wfile.write(
                    f"Content-Length: {len(frame)}\r\n\r\n".encode()
                )
                self.wfile.write(frame)
                self.wfile.write(b"\r\n")
                time.sleep(target_interval)
        except (BrokenPipeError, ConnectionResetError):
            logger.info("Client disconnected from stream")

    def _handle_health(self):
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(b'{"status":"ok","service":"pi5-camera-stream"}')

    def _handle_index(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        html = """<!DOCTYPE html>
<html><head><title>Pi5 Camera</title></head>
<body style="margin:0;background:#000;display:flex;align-items:center;justify-content:center;height:100vh">
<img src="/stream" style="max-width:100%;max-height:100vh" />
</body></html>"""
        self.wfile.write(html.encode())

    def log_message(self, format, *args):
        logger.debug(format, *args)


class ThreadedHTTPServer(HTTPServer):
    """HTTP server xử lý mỗi request trên thread riêng (hỗ trợ nhiều client)."""

    def process_request(self, request, client_address):
        thread = threading.Thread(
            target=self.process_request_thread,
            args=(request, client_address),
            daemon=True,
        )
        thread.start()

    def process_request_thread(self, request, client_address):
        try:
            self.finish_request(request, client_address)
        except Exception:
            self.handle_error(request, client_address)
        finally:
            self.shutdown_request(request)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Pi 5 MJPEG Camera Stream Server"
    )
    parser.add_argument(
        "--port", type=int, default=DEFAULT_PORT, help=f"HTTP port (default: {DEFAULT_PORT})"
    )
    parser.add_argument(
        "--fps", type=int, default=DEFAULT_FPS, help=f"Frame rate (default: {DEFAULT_FPS})"
    )
    parser.add_argument(
        "--width", type=int, default=DEFAULT_WIDTH, help=f"Frame width (default: {DEFAULT_WIDTH})"
    )
    parser.add_argument(
        "--height", type=int, default=DEFAULT_HEIGHT, help=f"Frame height (default: {DEFAULT_HEIGHT})"
    )
    parser.add_argument(
        "--device", default=None, help="Device index hoặc path cho USB camera (ví dụ: 0, 16 hoặc /dev/video16)"
    )
    return parser.parse_args()


def main():
    global camera_backend

    args = parse_args()
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    camera_backend = create_camera_backend(
        args.width, args.height, args.fps, device=args.device
    )

    server = ThreadedHTTPServer(("0.0.0.0", args.port), MJPEGHandler)

    def shutdown_handler(sig, frame):
        logger.info("Shutting down camera stream server...")
        camera_backend.stop()
        server.shutdown()
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown_handler)
    signal.signal(signal.SIGTERM, shutdown_handler)

    logger.info("📹 Pi5 MJPEG Camera Stream Server started")
    logger.info(f"   Stream URL : http://0.0.0.0:{args.port}/stream")
    logger.info(f"   Health URL : http://0.0.0.0:{args.port}/health")
    logger.info(f"   Preview    : http://0.0.0.0:{args.port}/")
    logger.info(f"   Resolution : {args.width}x{args.height} @ {args.fps}fps")

    server.serve_forever()


if __name__ == "__main__":
    main()
